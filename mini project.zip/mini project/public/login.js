/*  var tblUsers = document.getElementById('tbl_users_list');
  var databaseRef = firebase.database().ref('users/');
  var rowIndex = 1;
  
  databaseRef.once('value', function(snapshot) {
    snapshot.forEach(function(childSnapshot) {
   var childKey = childSnapshot.key;
   var childData = childSnapshot.val();
   
   var row = tblUsers.insertRow(rowIndex);
   var cellId = row.insertCell(0);
   var cellName = row.insertCell(1);
   cellId.appendChild(document.createTextNode(childKey));
   cellName.appendChild(document.createTextNode(childData.user_name));
   alert(childData.user_name);
   rowIndex = rowIndex + 1;
    });
  });

  */
 function login(){

  var email2= document.getElementById('email').value;
   
  var pswd=document.getElementById('pswd').value;
firebase.database().ref().child("users").orderByChild("email").equalTo("email2").once("value",function(snapshot){
  snapshot.forEach(function(childSnapshot)
  {
    var email=childSnapshot.child("email").value;
    var pass=childSnapshot.child("pswd").value;
    alert(email, pass);
  })
})

 }
  
