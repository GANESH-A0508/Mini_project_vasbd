function Register(){
    var name = document.getElementById('name').value;
    var uname= document.getElementById('uname').value;
    var gender = document.getElementById('gender').value;
    var email= document.getElementById('email').value;
    var dob=document.getElementById('dob').value;
    var phno=document.getElementById('phno').value;
    var add1=document.getElementById('add1').value;
    var add2= document.getElementById('add2').value;
    var myfile=document.getElementById('myfile').value;
    var pswd=document.getElementById('pswd').value;
    var cpswd=document.getElementById('cpswd').value;
   // alert(user_name);
   
    var uid = firebase.database().ref().child('users').push().key;
 
   // alert(user_name);
    
    var data = {
     user_id: uid,
     name: name,
     uname:uname,
     gender:gender,
     email:email,
     dob:dob,
     phno:phno,
     add1:add1,
     add2:add2,
     pswd:pswd
    }
    
    var updates = {};
    updates['/users/' + uid] = data;
    firebase.database().ref().update(updates);
    
    alert('The user is created successfully!');
    //reload_page();
   }